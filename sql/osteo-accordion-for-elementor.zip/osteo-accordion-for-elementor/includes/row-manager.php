<?php

namespace Osteo_Accordion;
defined( 'ABSPATH' ) || die();

add_filter ( 'plugin_action_links_'.OSTEO_ACCORDION_PLUGIN_BASE, function( $links ) {
    $link = sprintf( "<a href='%s' style='color: #E91E63; font-weight: 700'>%s</a>", esc_url( 'https://docs.twinkletheme.com/docs/osteo-accordion-for-elementor/installation/'), esc_html__('Documentation', 'osteo-accordion'));
    array_push( $links, $link );
    
    return $links;
});